﻿using Microsoft.Win32;
using SignatureApp;
using System;
using System.Collections.Generic;
using System.Data.Linq;
using System.Data.OleDb;
using System.Data.SqlServerCe;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApplication1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        string filename = string.Empty;

        private ViewRecords viewRecords;
        public MainWindow()
        {
            InitializeComponent();
        }

        private void ViewRecordsButton_Click(object sender, RoutedEventArgs e)
        {
            viewRecords = new ViewRecords();
            viewRecords.Show();
            this.Close();
        }

        private void SaveBtn_Click(object sender, RoutedEventArgs e)
        {
            DeleteFileImage();
            SaveImage();
            Reset();
            this.Close();
        }

        public void DeleteFileImage()
        {
            string path = Environment.UserName;
            var MyIni = new IniFile(@"\ProgramData\Config.ini");
            string value = MyIni.IniReadValue("PathSignature", "Path");

            if (value == null || value == string.Empty)
            {
                filename = "C:\\Users\\" + path + "\\Pictures\\";
            }
            else
            {
                filename = value + "\\";
            }

            string[] filePaths = Directory.GetFiles(filename);
            foreach (string filePath in filePaths)
            {
                if (filePath.Contains("signature.jpg"))
                    File.Delete(filePath);
            }
        }

        private void SaveImage()
        {
            // Save document
            string path = Environment.UserName;
            var MyIni = new IniFile(@"\ProgramData\Config.ini");
            string value = MyIni.IniReadValue("PathSignature", "Path");

            if (value == null || value == string.Empty)
            {
                filename = "C:\\Users\\"+path+"\\Pictures\\signature.jpg";
            }
            else
            {
                filename = value + "\\signature.jpg";
            }

            //get the dimensions of the ink control
            int margin = (int)this.yourinkcanvas.Margin.Left;
            int width = (int)this.yourinkcanvas.ActualWidth - margin;
            int height = (int)this.yourinkcanvas.ActualHeight - margin;
            //render ink to bitmap
            RenderTargetBitmap rtb = new RenderTargetBitmap(width, height, 96d, 96d, PixelFormats.Default);
            rtb.Render(yourinkcanvas);

            using (FileStream fs = new FileStream(filename, FileMode.Create))
            {
               BmpBitmapEncoder encoder = new BmpBitmapEncoder();
               encoder.Frames.Add(BitmapFrame.Create(rtb));
               encoder.Save(fs);
            }
        }

        internal void LoadImage(string path)
        {
            try
            {
                BitmapImage b = new BitmapImage();
                yourinkcanvas.Strokes.Clear();
                b.BeginInit();
                b.CreateOptions = BitmapCreateOptions.PreservePixelFormat;

                b.UriSource = new Uri(path);
                b.DecodePixelWidth = 500;
                b.EndInit();

                Image i = new Image();
                i.Source = b;
                yourinkcanvas.Children.Add(i);
                SaveBtn.IsEnabled = false;
            }
            catch { }
        }

        private void Reset()
        {
            yourinkcanvas.Strokes.Clear();
            yourinkcanvas.Children.Clear();
            SaveBtn.IsEnabled = true;
        }

        private void ClearBtn_Click(object sender, RoutedEventArgs e)
        {
            Reset();
        }
    }
}

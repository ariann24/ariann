﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Linq.SqlClient;
using System.Data.OleDb;
using System.Data.SqlClient;
using System.Data.SqlServerCe;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfApplication1
{
    /// <summary>
    /// Interaction logic for ViewRecords.xaml
    /// </summary>
    public partial class ViewRecords : Window
    {
        private MainWindow mainWindow;
        OleDbConnection con = new OleDbConnection(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=SignatureDatabase.accdb");
        OleDbCommand cmd;
        public static string path;

        public ViewRecords()
        {
            InitializeComponent();
        }

        private void backBtn_Click(object sender, RoutedEventArgs e)
        {
            mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();
        }

        private void DisplayRecords()
        {
            con.Open();
            cmd = new OleDbCommand("Select * from Signature", con);
            OleDbDataAdapter sda = new OleDbDataAdapter(cmd);
            DataTable dt = new DataTable("Signature");
            sda.Fill(dt);
            RecordsGrid.ItemsSource = dt.DefaultView;
            con.Close();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            DisplayRecords();
        }

        private void SearchBtn_Click(object sender, RoutedEventArgs e)
        {
            Search();
        }

        private void Search()
        {
            con.Open();
            cmd = new OleDbCommand("Select * from Signature Where name like @param", con);
            cmd.Parameters.AddWithValue("@param", "%"+ SearchTxt.Text.Trim() + "%");
            OleDbDataAdapter sda = new OleDbDataAdapter(cmd);
            DataTable dt = new DataTable("Signature");
            sda.Fill(dt);
            RecordsGrid.ItemsSource = dt.DefaultView;
            con.Close();
        }

        private void SearchTxt_GotFocus(object sender, RoutedEventArgs e)
        {
            SearchTxt.Text = String.Empty;
        }

        private void RecordsGrid_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            mainWindow = new MainWindow();
            DataRowView row = (DataRowView)RecordsGrid.SelectedItems[0];
            path = row[2].ToString().Trim();
            mainWindow.LoadImage(path);
            this.Close();
            mainWindow.Show();
        }
    }
    
}

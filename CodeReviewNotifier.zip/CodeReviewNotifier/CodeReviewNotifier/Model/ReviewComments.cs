﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CodeReviewNotifier.Model
{
    public class ReviewComments
    {
        public string ID { get; set; }
        public string RilID { get; set; }
    }
}

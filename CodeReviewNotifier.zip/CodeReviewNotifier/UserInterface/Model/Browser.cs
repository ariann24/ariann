﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CodeReviewNotifier.Model
{
    class Browser
    {
        public string Name { get; set; }
        public string IconPath { get; set; }
        public string Path { get; set; }
    }
}
